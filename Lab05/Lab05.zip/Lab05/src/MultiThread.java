
public class MultiThread extends Thread {
	int j;
	int k;
	long sum; //합계의 경우 int의 범위를 넘어갈 수 있기에 long으로 한다.

	public MultiThread(int j, int k) { //받아온 데이터를 스레드에 입력한다.
		this.j = j;//스레드의 번호
		this.k = k;//스레드에서 계산해야 할 범위
		sum = 0;
	}

	public void run() {
		for (int i = 1; i <= k; i++) {
			sum += j * k + i; //합은 스레드 넘버에 계산범위를 곱한 값에 i를 더한 것들의 합
		}
	}
	
	public long getSum(){//스레드의 sum을 받아오는 메소드
		return sum;
	}
}
