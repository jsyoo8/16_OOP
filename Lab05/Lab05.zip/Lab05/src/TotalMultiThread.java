
public class TotalMultiThread {
	long result = 0;//결과값은 int의 범위를 넘어갈 수 있기에 long으로 한다.
	public String sum(int i, int j) {
		MultiThread[] mt = new MultiThread[j];//스레드의 배열을 생성한다.
		int k = i/j;//계산해야할 범위와 스레드의 갯수를 나눠서 각 스레드의 계산범위를 저장한다.
		for(int n = 0; n<j; n++){
			mt[n] = new MultiThread(n,k);//스레드 번호와 스레드의 계산범위를 주어진 상태로 생성한다.
			mt[n].start();//스레드 실행
		}
			wait(mt);//각 스레드가 계산이 완료되길 기다리게 하는 메소드
			add(mt);//계산완료된 각 스레드에서 sum값들을 result로 받아오는 과정
		return Long.toString(result);
	}
	public void wait(MultiThread[] mt){
		for(int i = 0; i< mt.length; i++){
			try {
				mt[i].join();//각 스레드들이 계산완료를 기다림
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void add(MultiThread[] mt){
		for(int i = 0; i< mt.length; i++){
			result += mt[i].getSum();//result의 값에 각 스레드들의 sum값을 더한다.
		}
	}
}
