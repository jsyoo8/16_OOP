
public class TestThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long start;
		TotalMultiThread tmt = new TotalMultiThread();

		System.out.print("1~100까지의 합 : " + tmt.sum(100, 10));
		System.out.println("\n<<1~N까지의 합 M개의 쓰레드로 계산 시간(ns)>>");

		for (int i = 16; i <= 134217728; i = i * 2) {//i가 2배씩 증가하며 범위는 16~134217728까지
			for (int j = 1; j <= 16; j = j * 2) {//j가 2배씩 증가하며 범위는 1~16까지
				start = System.nanoTime();//start에 계산 시작 시간 저장
				tmt.sum(i, j);//스레드 계산
				System.out.printf("%8d\t", System.nanoTime() - start);//tap만큼 떨어뜨려서 계산완료된 시간에서 시작시간을 뺀 값을 표시(실행시간)
			}
			System.out.println();
		}
	}

}
